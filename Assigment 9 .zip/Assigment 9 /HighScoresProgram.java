import java.util.Scanner;
public class HighScoresProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HighScores[] hs = new HighScores[5];
		initialize(hs);
		sort(hs);
		System.out.println("\n\n\n");
		display(hs);
	}
	public static void initialize(HighScores[] scores) {
		Scanner sc = new Scanner(System.in);
		for (int limit = 0; limit <= 4; limit++) {
			System.out.print("Enter the name for score #" + (limit + 1) + ": ");
			String name = sc.next();
			System.out.print("Enter the score for score #" + (limit + 1) + ": ");
			int numb = sc.nextInt();
			scores[limit] = new HighScores(name, numb);
		}
	}
	public static void sort(HighScores[] scores) {
		int startScan, index, maxIndex, maxValue;
		String nameValue = "";
		for (startScan = 0; startScan < (scores.length - 1); startScan++) {
		maxIndex = startScan;
			maxValue = scores[startScan].getScore();
			nameValue = scores[startScan].getName();

			for (index = startScan + 1; index < scores.length; index++) {
				if (scores[index].getScore() > maxValue) {
					maxValue = scores[index].getScore();
					nameValue = scores[index].getName();
					maxIndex = index;
						}
					}

					scores[maxIndex].setScore(scores[startScan].getScore());
					scores[startScan].setScore(maxValue);

					scores[maxIndex].setName(scores[startScan].getName());
					scores[startScan].setName(nameValue);
				}
			}

	public static void display(HighScores[] scores) {
		System.out.println("Top Scorers:");
		for (int y = 0; y <= scores.length - 1; y++) {
			System.out.println(scores[y].getName() + ": " + scores[y].getScore());
				}
			}
		}


