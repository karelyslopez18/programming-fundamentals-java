
public class HighScores {
	private int score;
	private String name;
	
	HighScores(String n, int s){
		this.name = n;
		this.score = s;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String toString() {
		return this.name + " | " + this.score;
	}
}
