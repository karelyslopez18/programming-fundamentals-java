/***
 * 
 * @author karelyslopez
 *
 */

public class MyCircle {
	private double x;
	private double y;
	private double r;

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public double getR() {
		return r;
	}

	public void setR(double r) {
		this.r = r;
	}

	public double getArea1(double r1) {
		return 3.14 * Math.pow(r1, 2);
	}

	public boolean doesOverlap(MyCircle circle) {
		double a = this.x - circle.x;
		double b = this.y - circle.y;
		double c = (Math.pow(a, 2) + Math.pow(b, 2));
		double sum = this.r + circle.r;
		return !(Math.sqrt(c) > sum);
	}

}
