/***
 * 
 * @author karelyslopez
 *
 */

public class MyCircleTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MyCircle c1 = new MyCircle();
		MyCircle c2 = new MyCircle();
		MyCircle c3 = new MyCircle();

		c1.setR(6);
		c1.setX(-7);
		c1.setY(-9);

		c2.setR(8);
		c2.setX(-4);
		c2.setY(-6);

		c3.setR(2.3);
		c3.setX(3);
		c3.setY(4);

		System.out.println("Circle 1 - [R: " + c1.getR() + ", X: " + c1.getX() + ", Y: " + c1.getY() + "]");
		System.out.println("Circle 2 - [R: " + c2.getR() + ", X: " + c2.getX() + ", Y: " + c2.getY() + "]");
		System.out.println("Circle 3 - [R: " + c3.getR() + ", X: " + c3.getX() + ", Y: " + c3.getY() + "]");
		System.out.println("Does Circle 1 overlap with Circle 2? " + c1.doesOverlap(c2));
		System.out.println("Does Circle 2 overlap with Circle 3? " + c2.doesOverlap(c3));
		System.out.println("Does Circle 1 overlap with Circle 3? " + c1.doesOverlap(c3));
	}

}
