import java.util.Scanner;

public class StringProcessorProgram {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char ask2 ='y';
		while (ask2 == 'y') {
			Scanner sc = new Scanner(System.in);
			System.out.print("Enter a line of text:");
			String text = sc.nextLine();
			StringProcessor sp = new StringProcessor();
			sp.setString(text);
			Scanner input= new Scanner(System.in);
			
			System.out.println("words: " + sp.wordCount());
			System.out.println("uppercase: " + sp.uppercaseCount());
			System.out.println("digits: " + sp.digitCount());
			System.out.println("digit words: " + sp.digitwordCount());
			System.out.println("line with whitespace removed: " + sp.getNoSpaceString());
			System.out.println("line with vowels replaced: " + sp.getNoVowelString());
			System.out.println("line with digit words replaced: " + sp.getNoDigitWordString());
			
			
			System.out.print("do you want to enter another? (y/n): ");
			ask2 = sc.next().charAt(0);
		}
	}
}

		
	

