
	public class StringProcessor {
		private String string;
	    
	public StringProcessor(String s){
		this.string= s;
	        }

	public StringProcessor() {
		this.string = "";
	}

	public String getString() {
		return string;
	}

	public void setString(String s) {
		this.string = s;
	}

	public int count(String s) {
		String[] words = s.split(" ");
		return words.length;
	}

	public int wordCount() {
		return getString().split(" ").length;
	}
	public int uppercaseCount() {
		int count = 0;
		char[] stringChars = getString().toCharArray();
		for(int x = 0; x <= stringChars.length - 1; x++) {
			int charAscii = (int) stringChars[x];
			if(charAscii >= 65 && charAscii <= 90) {
				count++;
			}
		}
		return count;
	}

	public int digitCount() {
		int count = 0;
		char[] stringChars = getString().toCharArray();
		for(int x = 0; x <= stringChars.length - 1; x++) {
			if(Character.isDigit(stringChars[x])) {
				count++;
			}
		}
		return count;
	}


	public int digitwordCount() {
		int count = 0;
		String[] words = getString().split(" ");
		String[] digits = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};
		for(int x = 0; x <= words.length - 1; x++) {
			for(int y = 0; y <= digits.length - 1; y++) {
				if(words[x].equalsIgnoreCase(digits[y])) {
					count ++;
				}
			}
		}
	 	return count;
	}

	public  String getNoSpaceString() {
		return string.replaceAll("\\s+", "");
	}
	public String getNoVowelString() {
		return string.replaceAll("[AEIOUaeiou]", "-");
	}

	public String getNoDigitWordString() {
		String[] words = getString().split(" ");
		String[] digits = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};
		for(int x = 0; x <= words.length - 1; x++) {
			for(int y = 0; y <= digits.length - 1; y++) {
				if(words[x].equalsIgnoreCase(digits[y])) {
					words[x] = String.valueOf(y);
				}
			}
		}
		return String.join(" ", words);
	}
	}


