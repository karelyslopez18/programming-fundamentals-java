/***
 * 
 * @author karelyslopez
 *
 */

public class Circle {
	private Point center;
	private double r;
	
	public Circle(Point o, double r){
		this.center = o;
		this.r = r;
	}
	
	public Circle(double xValue, double yValue, double r) {
		center = new Point();
		this.center.setX(xValue);
		this.center.setY(yValue);
		this.r = r;
	}
	
	public Circle() {
		center = new Point();
		this.center.setX(0);
		this.center.setY(0);
		this.r = 1;
	}

	public Circle(Circle c) {
		this.center = c.center;
		this.r = c.r;
	}
	
	public Point getCenter() {
		return center;
	}

	public void setCenter(Point center) {
		this.center = center;
	}

	public double getX() {
		return this.center.getX();
	}

	public void setX(double x) {
		this.center.setX(x);
	}

	public double getY() {
		return this.center.getY();
	}

	public void setY(double y) {
		this.center.setY(y);
	}

	public double getR() {
		return r;
	}

	public void setR(double r) {
		this.r = r;
	}

	public double getArea1(double r1) {
		return 3.14 * Math.pow(r1, 2);
	}

	public boolean doesOverlap(Circle circle) {
		double a = this.center.getX() - circle.getX();
		double b = this.center.getY() - circle.getY();
		double c = (Math.pow(a, 2) + Math.pow(b, 2));
		double sum = this.r + circle.r;
		return !(Math.sqrt(c) > sum);
	}

	public String toString() {
		return "Circle Data => X: " + this.center.getX() + ", Y: " + this.center.getY() + ", R: " + this.r;
	}
	
	public boolean equals(Circle circle) {
		return (this.center.getX() == circle.getX() && this.center.getY() == circle.getY() && this.r == circle.r);
	}
}