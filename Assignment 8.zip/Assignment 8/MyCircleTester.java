/***
 * 
 * @author karelyslopez
 *
 */

public class MyCircleTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle ci1 = new Circle();
		Circle ci2 = new Circle();
		Circle ci3 = new Circle();

		ci1.setR(6);
		ci1.setY(-9);
		ci1.setX(-7);

		ci2.setR(8);
		ci2.setX(-4);
		ci2.setY(-6);

		ci3.setR(2.3);
		ci3.setX(3);
		ci3.setY(4);

		System.out.println("Circle 1 - [R: " + ci1.getR() + ", X: " + ci1.getX() + ", Y: " + ci1.getY() + "]");
		System.out.println("Circle 2 - [R: " + ci2.getR() + ", X: " + ci2.getX() + ", Y: " + ci2.getY() + "]");
		System.out.println("Circle 3 - [R: " + ci3.getR() + ", X: " + ci3.getX() + ", Y: " + ci3.getY() + "]");
		System.out.println("Does Circle 1 overlap with Circle 2? " + ci1.doesOverlap(ci2));
		System.out.println("Does Circle 2 overlap with Circle 3? " + ci2.doesOverlap(ci3));
		System.out.println("Does Circle 1 overlap with Circle 3? " + ci1.doesOverlap(ci3));
		System.out.println("Is equal? " + ci1.equals(ci1));
		System.out.println("Is equal? " + ci1.equals(ci2));
		System.out.println(ci1.toString());
	}
}
