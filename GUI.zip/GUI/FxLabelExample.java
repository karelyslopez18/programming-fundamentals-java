import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

public class FxLabelExample extends Application
{
	public static void main(String[] args){
		Application.launch(args);
		}

	@Override
	public void start(Stage stage) {
		
		TextField CelsiusFld = new TextField();
		Label CelsiusLbl = new Label("Convert");
		Label Result = new Label("Fahrenheit: ");
		
		CelsiusLbl.setLabelFor(CelsiusFld);
		CelsiusLbl.setMnemonicParsing(true);
		
		Button newBtn = new Button("Convert");
		CelsiusFld.setText("0");
		newBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override public void handle(ActionEvent e)
            {
				if(CelsiusFld.getText().isEmpty()) {
					ConvertingtoFahrenheit ctf = new ConvertingtoFahrenheit(0.0);
					Result.setText("Fahrenheit: " + ctf.toFahrenheit());
				} else {
					ConvertingtoFahrenheit ctf = new ConvertingtoFahrenheit(Double.parseDouble(CelsiusFld.getText()));
					Result.setText("Fahrenheit: " + ctf.toFahrenheit());
				}
				
            }
		});
		
		
		GridPane root = new GridPane();
		root.setMinSize(250, 50);
		root.addRow(0, CelsiusFld, newBtn);
		root.addRow(2, Result);
		
		/* 
		 * Set the padding of the GridPane
		 * Set the border-style of the GridPane
		 * Set the border-width of the GridPane
		 * Set the border-insets of the GridPane
		 * Set the border-radius of the GridPane
		 * Set the border-color of the GridPane
		*/
		root.setStyle("-fx-padding: 10;" +
				"-fx-border-style: solid inside;" +
				"-fx-border-width: 2;" +
				"-fx-border-insets: 5;" +
				"-fx-border-radius: 5;" +
				"-fx-border-color: grey;");
		
		Scene scene = new Scene(root);
		stage.setScene(scene);
		stage.setTitle("Celsius Converter");
		stage.centerOnScreen();
		stage.show();

}
}