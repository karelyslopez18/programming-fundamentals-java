
public class ConvertingtoFahrenheit {
	private double celsuis;
	
	ConvertingtoFahrenheit( int c){
		this.celsuis = c;
	}
	
	ConvertingtoFahrenheit( double c){
		this.celsuis = c;
	}

	public double getCelsuis() {
		return celsuis;
	}

	public void setCelsuis(double celsuis) {
		this.celsuis = celsuis;
	}
	
	public double toFahrenheit() {
		return Math.floor((this.celsuis * 1.8 + 32) * 100) / 100;
	}

}
